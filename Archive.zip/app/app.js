angular.module('cossapDemo', [

    'cossap.catalogue',
    'cossap.charts',
    'cossap.charts.stream',
    'cossap.cesiumpanel',
	'cesium.drawhelper',
	'cesium.minimap',
    'cesium.picker'

  ]
);